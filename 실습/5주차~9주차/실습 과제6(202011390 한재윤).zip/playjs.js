function calc() {
	var x = document.getElementById('x').value;
	var y = document.getElementById('y').value;
	var sum;
	sum = parseInt(x) + parseInt(y);
	document.getElementById("sum").value = sum;
}


var computerNumber = 53;
var nGuesses = 0;

function guess() {

	var user = document.getElementById('user').value;

	if(user > computerNumber){
		document.getElementById("result").value = "높습니다.";
		nGuesses++;
		document.getElementById("guesses").value = parseInt(nGuesses);
	}
	else if(user < computerNumber){
		document.getElementById("result").value = "낮습니다.";
		nGuesses++;
		document.getElementById("guesses").value = parseInt(nGuesses);
	}	
	else {
		document.getElementById("result").value = "정답입니다.";
		nGuesses++;
		document.getElementById("guesses").value = parseInt(nGuesses);
	}	
}

function replay() {

	nGuesses = 0;

	computerNumber = Math.floor(Math.random() * 100 + 1);
	document.getElementById("user").value = "";
	document.getElementById("guesses").value = nGuesses;
	document.getElementById("result").value = "";

}

function setCTime() {
	var now = new Date();
	var monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" ];
	var s = monthNames[now.getMonth()] + " " + (now.getMonth() + 1) + ". " + now.getDate() + " " + now.getHours()  + ":" + now.getMinutes() + ":" + now.getSeconds();
	document.getElementById('ctime').innerHTML = s;
	setTimeout('setCTime()',1000);
}


// constants
var POSSIBLE_WORDS = ["obdurate","verisimilitude","defenestrate", "obsequious", "dissonant","toady","idempotent"];
var MAX_GUESSES = 6;

// global variables
var guesses = "";
var guessCount = MAX_GUESSES;
var word;

function newGame(){
	var randomIndex = parseInt(Math.random()*POSSIBLE_WORDS.length);
	word = POSSIBLE_WORDS[randomIndex];
	guessCount = MAX_GUESSES;
	guesses = "";
	var guessButton = document.getElementById("guessbutton");
	guessButton.disabled = false;
	updatePage();
}

function guessLetter(){

	var input = document.getElementById("hguess");
	var clue = document.getElementById("clue");
	var letter = input.value
	if(guessCount==0 || clue.innerHTML.indexOf("_") < 0 || guesses.indexOf(letter) >= 0){
		return;
	}
	guesses += letter;
	if(word.indexOf(letter)<0){
		guessCount--;
	}
	updatePage();
}

function updatePage(){

	var clueString = "";
	for(var i=0;i<word.length;i++){
		var letter = word.charAt(i);
		if(guesses.indexOf(letter)>=0){
			clueString += letter + " ";
		}else{
			clueString += "_ ";
		}
	}
	var clue = document.getElementById("clue");
	clue.innerHTML = clueString;

	var guessArea = document.getElementById("guessstr");
	if(guessCount==0){
		guessArea.innerHTML = "You lose.";
	}else if (clueString.indexOf("_")<0){
		guessArea.innerHTML = "You win.";
	}else{
		guessArea.innerHTML = "Guesses: " + guesses;
	}

	var image = document.getElementById("hangmanpic");
	image.src = "hangman"+ guessCount + ".gif";
}