var i=0;
var index=0;
var imgArray = ["img1.jpg","img2.jpg","img3.jpg","img4.jpg","img5.jpg","img6.jpg"];


$(document).ready(function(){

	$("div.out").mouseover(function(){
		$("p:first",this).text("mouse over");
		$("p:last",this).text(++i);
	});

	$("div.out").mouseout(function(){
		$("p:first",this).text("mouse out");
	});

	$("#b1").on("click", 
	{url:"http://www.google.com", 
	winattributes:"resize=1, scrollbars=1, status=1"}, max_open);

	$("#bind").click(function(){
		$("body")
		.on("click","#theone",flash)
		.find("#theone")
		.text("Can Click!");
	});

	$("#unbind").click(function(){
		$("body")
		.off("click","#theone",flash)
		.find("#theone")
		.text("Does nothing...");
	});

	$("#trigger_test button:first").click(function(){
		update($("span:first"));
	})

	$("#trigger_test button:last").click(function(){
		$("#trigger_test button:first").trigger("click");
		update($("span:last"));
	})

	$("#image").click(function(){
		if($("#image").attr("src") == "img1.png"){
			$("#image").attr("src","img2.png")
		}
		else{
			$("#image").attr("src","img1.png")
		}
	})

	$("#imgAlbum").click(function(){
		if(index==0){
			$("#imgAlbum").attr("src", imgArray[index])
		}
		index++;
		if(index==6){
			index=0;
		}
		$("#imgAlbum").attr("src", imgArray[index])
	});
});

function max_open(event){
	var maxwindow = window.open(event.data.url,"",event.data.winattributes);
	maxwindow.moveTo(0,0);
	maxwindow.resizeTo(screen.availWidth,screen.availHeight); 	
}

function flash(){
	$("#off_test").show().fadeOut("slow");
}

function update(j){
	var n = parseInt(j.text(),10);
	j.text(n+1);
}